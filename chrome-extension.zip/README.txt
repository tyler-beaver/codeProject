Dashboard Auto-Fill Chrome Extension

1. Open Chrome and go to chrome://extensions/
2. Enable Developer Mode (top right)
3. Click "Load unpacked" and select this chrome-extension folder
4. Visit your site and test the submit button

Edit content.js to adjust selectors or the auto-filled value as needed.